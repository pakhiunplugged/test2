<?php
session_start();
$admin_name=$_SESSION['admin_name'];
$admin_id=$_SESSION['admin_id'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Dashboard</title>
<link href="../css/style1.css" rel="stylesheet" type="text/css" />
 <link rel="stylesheet" href="../css/fontello.css">
    <link rel="stylesheet" href="../css/animation.css">
<link rel="icon" type="image/png" href="../images/fevicon.ico" />
</head>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<body>
<div >
    <div class="abc">
    	
    </div>
</div>
</body>

</html>