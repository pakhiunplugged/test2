<?php 
$conn=mysqli_connect("localhost","root","","apartment");
if(!$conn)
{
	echo "Could not connect to database";
}
?>